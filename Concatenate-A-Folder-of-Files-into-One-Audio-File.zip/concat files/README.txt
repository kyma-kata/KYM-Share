README

"Concat A Folder" Sound takes a folder of audio files and concatenates them all into one long audio file. Currently, the implementation is in mono. The concatenation is alphabetical (how the folder of files is read).

Notes: Be sure that the audio files in the folder are the same samplerate as the SignalProcessor (44100), or you will get errors. I had some issues with index out of bounds for a folder of files made at half the sample rate during tests. (Thanks to Gustav for pointing this out)

///// Step-By-Step //////
- Play the Sound (with or without space).
- First Prompt: Name the file you want to write out to.
- Second Prompt: Select a sample in a folder of audio files (I've only tried a folder of just audio files)
- The new file will write silently and then play silently after its done. It's fast! Cmd-K and then go view your newly concatenated file.

///// A bit about each file //////
Concat to Mono: You can concat mono or stereo files down to a mono file.
Concat to Mono (space): Adds silence in between each file. Default is 250ms (or 11025 samples at 44100 sample rate).
Concat to Stereo: You can concat mono or stereo files into a stereo file (the mono files will be in both left and right channels)
Concat to Stereo (space): Adds silence in between each file. Default is 250ms (or 11025 samples at 44100 sample rate).

Have fun!
- Jon Bellona
jon@jpbellona.com


CHANGELOG

v1.1
------------------------------------
	- added stereo compatibility
	- mono is now summed L+R
------------------------------------

v1.0 
------------------------------------
	- initially release. mono files
------------------------------------