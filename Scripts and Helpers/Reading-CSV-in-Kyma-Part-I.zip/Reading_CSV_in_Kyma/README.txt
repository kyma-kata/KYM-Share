README

The files are first in a two-part series for working with CSV files inside of Kyma. This file deals with reading single-column CSV files (no delimiter) in Kyma and mapping them onto five parameters of sound (pitch, amplitude, timbre, location, duration).

The post can be found on the Kyma Insights online magazine.
http://kyma.symbolicsound.com/insights/

One may also access the related walk-through directly.
http://jpbellona.com/reading-csv-files-inside-kyma/

If you have questions or comments, please send me an email at jon@jpbellona.com. Thanks!

