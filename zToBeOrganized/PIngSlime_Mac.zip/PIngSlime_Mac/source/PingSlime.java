import processing.core.*; 
import processing.xml.*; 

import oscP5.*; 
import netP5.*; 
import controlP5.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class PingSlime extends PApplet {

/** 

*  PING SLIME! 
*  for Kyma users - send the first handshake message to the Paca(rana) hardware or 
*  a local OSC router ( like OSCulator ) so that Kyma can begin to send that OSC message..

*  by Cristian Vogel 2010
*  thanks to A.Schlegel for the P5 libs



*/
 



  
OscP5 oscP5;
NetAddress myRemoteLocation;
ControlP5 controlP5;

String msg = "", msgToSend = "";
String ip = "";
Textfield ipInput, messageInput;
Textlabel ipText, messageText;
int bitFont;

PFont font;

boolean clicked = false;
  
public void setup() {
  size(400,300);
  frameRate(25);
  font = loadFont("FreeMonoBold-24.vlw");
  textFont(font, 36);

 controlP5 = new ControlP5(this);
 
// ipInput = ControlP5.addTextField("IP Address :: Paca(rana) IP or 127.0.0.1 for local (OSCulator etc) ::",20,55,390,100);
  ipInput = controlP5.addTextfield("IP_Address",100,70,200,20);
  ipInput.setFocus(true); 
  ipText = controlP5.addTextlabel ("IPlabel", ":: enter Paca (rana) IP or 127.0.0.1 for local machine (OSCulator etc) ::", 30,55);
 
  messageInput =  controlP5.addTextfield("OSC_Message",100,110,200,20);
 
 
   /* start oscP5, listening for incoming messages at port 9000 */
  oscP5 = new OscP5(this,8000);

smooth();



}


public void draw() {
  
  
  textSize(24);
  text("PING SLIME!  " ,10,10,390,50);
  noSmooth();
   textSize(18);
  text("click to focus and RETURN to send",10,30,390,50);
 smooth();
  textSize(36); textAlign(LEFT);
  
  
 
  
  if (msg.equals("")) {
 fill(0,10);
  rect(0,50,400,400); 
  } 
  
  
  
}


public void IP_Address(String input) {
  
  ip = input;
  
  ipInput.setCaptionLabel(ip);
 msg = "";  
 

}

public void OSC_Message(String messageInput) {
  println(messageInput);
  msgToSend=messageInput;
  
  
}

  
public void keyPressed() {
 
 if (key == ESC) { oscP5.stop();}
 
 if ((key == BACKSPACE) && (!msg.equals(""))) {
 if (msg.length() > 0) {
 msg=msg.substring(0,msg.length()-1);
 fill(0);rect(0,50,400,400); fill(255); text (msg,map(msg.length(),0,35,150,0),200);
  }
 return;}
  
  
  if (key == ENTER) {
    
    if (ip.equals("")) { msg=""; fill(0);rect(0,50,400,400); ipInput.setCaptionLabel("EMPTY IP !!");  }
    
    if ((!ip.equals("")) && (!msgToSend.equals(""))  && ( messageInput.isFocus())) {
     
  
    println(msgToSend);
  
 
  myRemoteLocation = new NetAddress(ip,8000);
  
  OscMessage myMessage = new OscMessage("/"+msgToSend);      
  
  myMessage.add(random(1)); /* add a float to the osc message */

  /* send the message */
  oscP5.send(myMessage, myRemoteLocation); 
  
  myMessage.clear();
  
  oscP5.send(myMessage, myRemoteLocation);
  
  
  
    msg = "";}
  }
  
  else {
  fill(0);rect(0,50,400,400);
  textSize(map(msg.length(),0,36,36,8));
  msg+= key;  fill(255); text (msg,map(msg.length(),0,35,150,0),200);

  }
  
  
  
}

  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#c0c0c0", "PingSlime" });
  }
}
